from setuptools import setup

setup(name='TicTacToe_python_game', 
	version='0.1', 
	description='Tictactoe Game', 
	packages=['TicTacToe_python_game'], 
	author='Aman Kumbhani',
	author_email='amankumbhani@gmail.com',
	zip_safe=False)